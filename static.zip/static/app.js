/* ============================================================
   FIELD SURVEY — client
   ============================================================ */

const FORMS = {
  tree:   {code:'T', label:'Tree'},
  shrub:  {code:'S', label:'Shrub'},
  vine:   {code:'V', label:'Vine / liana'},
  forb:   {code:'H', label:'Herb / forb'},
  grass:  {code:'G', label:'Grass / sedge / rush'},
  fern:   {code:'F', label:'Fern / moss'},
  fungus: {code:'M', label:'Fungus'},
  other:  {code:'·', label:'Other'}
};
const STATUS = {
  cultivated:{label:'Cultivated',       color:'#3FC8E4'},
  wild:      {label:'Wild / volunteer', color:'#E8E6DE'},
  invasive:  {label:'Invasive / remove',color:'#FF3B6B'},
  unknown:   {label:'Unidentified',     color:'#A578FF'}
};
const CONF  = {certain:'Certain', probable:'Probable', tentative:'Tentative'};
const ABUND = {'':'—', single:'Single', few:'Few (2–10)', patch:'Patch', stand:'Stand / dominant'};
const PHENO = {'':'—', vegetative:'Vegetative', budding:'Budding', flowering:'Flowering',
               fruiting:'Fruiting', senescent:'Senescent', dormant:'Dormant'};
const NATIVE_ZOOM = {esri:20, usgs:16, osm:19};   // measured, not assumed
const ATTR = {
  esri:'Esri, Maxar, Earthstar Geographics',
  usgs:'USGS National Map · NAIP',
  osm:'OpenStreetMap contributors'
};

let cfg = null;
let records = [];
let markers = new Map();
let filters = {cultivated:true, wild:true, invasive:true, unknown:true};
let editingId = null, draftConf = 'probable', draftSrc = 'manual', draftAcc = null;
let pendingPhotos = [];          // files chosen before a new record exists
let formPhotos = [];             // photos already on disk for the open record
let gpsWatch = null, gpsMarker = null, gpsCircle = null, following = false, gpsAcc = null;
let tileLayer = null;
let boundaryLayer = null;
let drawing = false, drawPts = [], drawLine = null, drawDots = [];

const $ = id => document.getElementById(id);
const api = async (url, opt) => {
  const r = await fetch(url, opt);
  if(!r.ok){
    let m = r.statusText;
    try{ m = (await r.json()).detail || m; }catch(e){}
    throw new Error(m);
  }
  return r.status === 204 ? null : r.json();
};
const esc = s => String(s == null ? '' : s)
  .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
  .replace(/"/g,'&quot;').replace(/'/g,'&#39;');
/* Local calendar date. toISOString() is UTC — on an evening survey it would
   stamp tomorrow's date on today's observation. */
const today = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
};
const fmt = n => n.toFixed(6);

/* ---------------------------------------------------------- map */
const map = L.map('map', {zoomControl:false, maxZoom:22}).setView([35.7199,-79.1775], 16);
L.control.scale({position:'bottomleft', metric:true, imperial:true}).addTo(map);

function setBasemap(k){
  if(tileLayer) map.removeLayer(tileLayer);
  tileLayer = L.tileLayer(`/tiles/${k}/{z}/{x}/{y}`, {
    attribution: ATTR[k], maxZoom: 22, maxNativeZoom: NATIVE_ZOOM[k] || 19
  }).addTo(map);
  document.querySelectorAll('#bmSeg button').forEach(b => b.classList.toggle('on', b.dataset.v === k));
  cfg.basemap = k;
  api('/api/config/basemap', {
    method:'PUT', headers:{'Content-Type':'application/json'}, body:JSON.stringify(k)
  }).catch(()=>{});
}

/* The reticle is the instrument. On phones it sits at the map's true centre;
   on desktop the stylesheet shifts it +180px so it centres in the visible map
   area beside the sidebar. Everything that marks a point — records, boundary
   corners, the HUD readout — must read the point under the reticle, which is
   NOT map.getCenter() on desktop. */
function reticlePoint(){
  const r = $('reticle').getBoundingClientRect();
  const m = map.getContainer().getBoundingClientRect();
  return L.point(r.left + r.width / 2 - m.left, r.top + r.height / 2 - m.top);
}
const reticleLatLng = () => map.containerPointToLatLng(reticlePoint());
/* setView such that latlng lands under the reticle rather than the true centre */
function centerOnReticle(latlng, zoom){
  const z = zoom == null ? map.getZoom() : zoom;
  const off = map.getSize().divideBy(2).subtract(reticlePoint());
  map.setView(map.unproject(map.project(latlng, z).add(off), z), z, {animate:false});
}

function paintCoords(){
  const c = reticleLatLng();
  $('cLat').textContent = fmt(c.lat);
  $('cLng').textContent = fmt(c.lng);
}
map.on('move', paintCoords);
/* A user pan means "stop following me". A programmatic setView from the GPS
   callback also fires movestart; the squelch flag tells the two apart. */
let squelchUnfollow = false;
map.on('movestart', () => {
  if(!squelchUnfollow && following && !drawing){ following = false; syncGps(); }
});

/* ---------------------------------------------------------- records */
function pinIcon(r){
  const s = STATUS[r.status] || STATUS.unknown;
  const f = FORMS[r.growth_form] || FORMS.other;
  return L.divIcon({
    className:'', iconSize:[26,26], iconAnchor:[13,13], popupAnchor:[0,-15],
    html:`<div class="pin" style="background:${s.color}">${f.code}</div>`
  });
}
function labelHTML(r){
  const s = STATUS[r.status] || STATUS.unknown;
  const f = FORMS[r.growth_form] || FORMS.other;
  const fix = r.fix_source === 'gps'
    ? `GPS ±${r.gps_accuracy_m != null ? Math.round(r.gps_accuracy_m) : '?'} m`
    : 'Hand-placed';
  const photos = (r.photos || []).map(p =>
    `<a href="/photos/${esc(p.filename)}" target="_blank" rel="noopener"><img src="/photos/${esc(p.thumb || p.filename)}" alt="" loading="lazy"></a>`).join('');
  return `<div class="lbl">
    <div class="photos">${photos}</div>
    <div class="status" style="color:${s.color}">${esc(s.label)} · ${esc(f.label)}</div>
    <h3>${esc(r.common_name || '(no common name)')}</h3>
    ${r.scientific_name ? `<div class="bin">${esc(r.scientific_name)}</div>` : ''}
    <dl>
      ${r.family ? `<dt>Family</dt><dd>${esc(r.family)}</dd>` : ''}
      <dt>Det.</dt><dd>${esc(CONF[r.det_confidence] || '—')}</dd>
      ${r.abundance ? `<dt>Abund.</dt><dd>${esc(ABUND[r.abundance])}</dd>` : ''}
      ${r.phenology ? `<dt>Phen.</dt><dd>${esc(PHENO[r.phenology])}</dd>` : ''}
      <dt>Obs.</dt><dd>${esc(r.date_observed)}</dd>
      <dt>Pos.</dt><dd>${r.lat.toFixed(6)}, ${r.lng.toFixed(6)}</dd>
      <dt>Fix</dt><dd>${esc(fix)}</dd>
    </dl>
    ${r.notes ? `<div class="notes">${esc(r.notes)}</div>` : ''}
    <div class="acts">
      <button onclick="editRec('${r.id}')">Edit</button>
      <button onclick="cloneRec('${r.id}')">Log another</button>
      <button class="del" onclick="delRec('${r.id}')">Delete</button>
    </div>
  </div>`;
}
function visible(){
  const q = $('search').value.trim().toLowerCase();
  return records.filter(r => {
    if(!filters[r.status]) return false;
    if(!q) return true;
    return [r.common_name, r.scientific_name, r.family, r.notes]
      .join(' ').toLowerCase().includes(q);
  });
}
function drawMarkers(){
  markers.forEach(m => map.removeLayer(m));
  markers.clear();
  visible().forEach(r => {
    const m = L.marker([r.lat, r.lng], {icon:pinIcon(r)})
      .bindPopup(labelHTML(r), {autoPanPadding:[24,90]}).addTo(map);
    markers.set(r.id, m);
  });
}
function drawList(){
  const rows = visible();
  const list = $('list');
  const taxa = new Set(records.map(r =>
    (r.scientific_name || r.common_name || '').toLowerCase()).filter(Boolean));
  $('count').innerHTML =
    `${records.length} record${records.length === 1 ? '' : 's'}<em>${taxa.size} taxa</em>`;

  if(!rows.length){
    list.innerHTML = records.length
      ? `<div class="empty"><b>Nothing matches</b>Clear the filter, or switch a status chip back on.</div>`
      : `<div class="empty"><b>Nothing pinned yet</b>Aim the reticle at a plant and press <span style="color:var(--bone)">Mark here</span>.<br>Tap ◎ to snap the reticle to your GPS.</div>`;
    return;
  }
  list.innerHTML = rows.map(r => {
    const s = STATUS[r.status] || STATUS.unknown;
    const f = FORMS[r.growth_form] || FORMS.other;
    const meta = [CONF[r.det_confidence], r.abundance ? ABUND[r.abundance] : null, r.date_observed]
      .filter(Boolean).join(' · ');
    const th = (r.photos && r.photos.length)
      ? `<img class="rthumb" src="/photos/${esc(r.photos[0].thumb || r.photos[0].filename)}" alt="" loading="lazy">` : '';
    return `<div class="row" data-id="${r.id}">
      <div class="badge" style="background:${s.color}">${f.code}</div>
      <div class="rmain">
        <div class="rname">${esc(r.common_name || r.scientific_name)}</div>
        ${r.scientific_name && r.common_name ? `<div class="rsci">${esc(r.scientific_name)}</div>` : ''}
        <div class="rmeta">${esc(meta)}</div>
      </div>
      ${th}
      <button class="rdup" data-dup="${r.id}" title="Log another here" aria-label="Log another of this taxon">⧉</button>
    </div>`;
  }).join('');
}
async function drawTaxa(){
  const t = await api('/api/taxa').catch(() => []);
  $('taxaList').innerHTML = t.length ? t.map(x => {
    const s = STATUS[x.status] || STATUS.unknown;
    const f = FORMS[x.growth_form] || FORMS.other;
    const isSci = x.taxon === x.common_name ? false : true;
    return `<div class="row" style="cursor:default">
      <div class="badge" style="background:${s.color}">${f.code}</div>
      <div class="rmain">
        <div class="${isSci ? 'rsci' : 'rname'}" style="${isSci ? 'color:var(--bone)' : ''}">${esc(x.taxon)}</div>
        <div class="rmeta">${esc([x.family, x.first_seen === x.last_seen ? x.last_seen : `${x.first_seen} → ${x.last_seen}`].filter(Boolean).join(' · '))}</div>
      </div>
      <div class="rn">×${x.n}</div>
    </div>`;
  }).join('') : `<div class="empty"><b>No species yet</b>Pin a plant and it shows up here.</div>`;
}
function fillDatalists(){
  const c = [...new Set(records.map(r => r.common_name).filter(Boolean))].sort();
  const s = [...new Set(records.map(r => r.scientific_name).filter(Boolean))].sort();
  $('commonList').innerHTML = c.map(v => `<option value="${esc(v)}">`).join('');
  $('sciList').innerHTML    = s.map(v => `<option value="${esc(v)}">`).join('');
}
function render(){ drawMarkers(); drawList(); fillDatalists(); drawTaxa(); }

async function reload(){
  records = await api('/api/plants');
  render();
  const st = await api('/api/status').catch(() => null);
  if(st){
    $('storeState').textContent =
      `${st.records} record${st.records === 1 ? '' : 's'} · ` +
      `${st.photos} photo${st.photos === 1 ? '' : 's'} · ` +
      `${st.tiles_cached} tiles cached (${st.tile_cache_mb} MB)`;
    $('dbPath').textContent = st.db;
    $('cacheState').textContent =
      `${st.tiles_cached} tiles on disk · ${st.tile_cache_mb} MB`;
  }
}

/* ---------------------------------------------------------- form */
function openForm(rec, prefill){
  editingId = rec ? rec.id : null;
  pendingPhotos = [];
  formPhotos = rec ? (rec.photos || []).slice() : [];
  const c = reticleLatLng();
  const r = Object.assign({
    common_name:'', scientific_name:'', family:'', growth_form:'tree', status:'wild',
    det_confidence:'probable', abundance:'', phenology:'', notes:'', date_observed:today(),
    lat:c.lat, lng:c.lng,
    fix_source: (following && gpsAcc != null) ? 'gps' : 'manual',
    gps_accuracy_m: (following && gpsAcc != null) ? gpsAcc : null
  }, rec || {}, prefill || {});

  $('formTitle').textContent = rec ? 'Edit record' : 'New record';
  $('fCommon').value = r.common_name;
  $('fSci').value    = r.scientific_name;
  $('fFamily').value = r.family;
  $('fForm').value   = r.growth_form;
  $('fStatus').value = r.status;
  $('fAbund').value  = r.abundance || '';
  $('fPheno').value  = r.phenology || '';
  $('fNotes').value  = r.notes;
  $('fDate').value   = r.date_observed;
  $('fLat').value    = r.lat;
  $('fLng').value    = r.lng;
  $('fLatTxt').textContent = fmt(r.lat);
  $('fLngTxt').textContent = fmt(r.lng);
  $('coordEdit').hidden = true;
  draftConf = r.det_confidence;
  draftSrc  = r.fix_source;
  draftAcc  = r.gps_accuracy_m;
  document.querySelectorAll('#fConf button').forEach(b => b.classList.toggle('on', b.dataset.v === draftConf));
  $('photoHint').hidden = !!rec;
  paintPhotoStrip();
  show('form');
  if(!rec) setTimeout(() => $('fCommon').focus(), 320);
}
function paintPhotoStrip(){
  const strip = $('photoStrip');
  const saved = formPhotos.map(p =>
    `<div class="pthumb">
       <img src="/photos/${esc(p.thumb || p.filename)}" alt="">
       <button type="button" data-rmphoto="${p.id}" aria-label="Remove photo">✕</button>
     </div>`).join('');
  const queued = pendingPhotos.map((f,i) =>
    `<div class="pthumb up">
       <span>queued</span>
       <button type="button" data-rmqueued="${i}" aria-label="Remove queued photo">✕</button>
     </div>`).join('');
  strip.innerHTML = saved + queued;
}
async function uploadPhoto(pid, file){
  const fd = new FormData();
  fd.append('file', file);
  const r = await fetch(`/api/plants/${pid}/photos`, {method:'POST', body:fd});
  if(!r.ok) throw new Error('upload failed');
  return r.json();
}
async function saveRec(){
  const body = {
    id: editingId,
    common_name: $('fCommon').value.trim(),
    scientific_name: $('fSci').value.trim(),
    family: $('fFamily').value.trim(),
    growth_form: $('fForm').value,
    status: $('fStatus').value,
    det_confidence: draftConf,
    abundance: $('fAbund').value,
    phenology: $('fPheno').value,
    notes: $('fNotes').value.trim(),
    date_observed: $('fDate').value || today(),
    lat: parseFloat($('fLat').value),
    lng: parseFloat($('fLng').value),
    fix_source: draftSrc,
    gps_accuracy_m: draftAcc
  };
  if(!body.common_name && !body.scientific_name){
    toast('Give it a common or scientific name'); $('fCommon').focus(); return;
  }
  if(!isFinite(body.lat) || !isFinite(body.lng)){ toast('Those coordinates are not numbers'); return; }

  $('saveBtn').disabled = true;
  $('saveBtn').textContent = 'Saving…';
  try{
    const saved = await api('/api/plants', {
      method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body)
    });
    if(pendingPhotos.length){
      $('saveBtn').textContent = `Uploading 0/${pendingPhotos.length}`;
      for(let i = 0; i < pendingPhotos.length; i++){
        try{ await uploadPhoto(saved.id, pendingPhotos[i]); }catch(e){ toast('A photo failed to upload'); }
        $('saveBtn').textContent = `Uploading ${i+1}/${pendingPhotos.length}`;
      }
    }
    hide('form');
    await reload();
    const m = markers.get(saved.id);
    if(m){
      const el = m.getElement();
      if(el) el.querySelector('.pin').classList.add('new');
    }
    toast(editingId ? 'Record updated' : `${saved.common_name || saved.scientific_name} logged`);
  }catch(e){
    toast(e.message || 'Save failed');
  }finally{
    $('saveBtn').disabled = false;
    $('saveBtn').textContent = 'Save record';
  }
}
window.editRec = id => {
  const r = records.find(x => x.id === id);
  if(r){ map.closePopup(); openForm(r); }
};
window.cloneRec = id => {
  const r = records.find(x => x.id === id);
  if(!r) return;
  map.closePopup(); toggleSheet(false);
  const c = reticleLatLng();
  openForm(null, {
    common_name:r.common_name, scientific_name:r.scientific_name, family:r.family,
    growth_form:r.growth_form, status:r.status, det_confidence:r.det_confidence,
    notes:'', lat:c.lat, lng:c.lng
  });
  toast('Same taxon, new position — aim the reticle');
};
window.delRec = async id => {
  const r = records.find(x => x.id === id);
  if(!r) return;
  if(!confirm(`Delete "${r.common_name || r.scientific_name}" and its photos? This cannot be undone.`)) return;
  await api(`/api/plants/${id}`, {method:'DELETE'});
  map.closePopup(); await reload(); toast('Record deleted');
};

/* ---------------------------------------------------------- GPS */
function syncGps(){
  $('gps').classList.toggle('on', following);
  $('reticle').classList.toggle('locked', following);
  $('reticle').classList.remove('seeking');
}
function toggleGps(){
  if(gpsWatch != null){
    navigator.geolocation.clearWatch(gpsWatch);
    gpsWatch = null; following = false; gpsAcc = null;
    [gpsMarker, gpsCircle].forEach(l => l && map.removeLayer(l));
    gpsMarker = gpsCircle = null;
    $('acc').textContent = '';
    syncGps();
    return;
  }
  if(!navigator.geolocation || !window.isSecureContext){
    toast('No GPS here — the page must be served over HTTPS or localhost');
    return;
  }
  following = true;
  $('reticle').classList.add('seeking');
  $('gps').classList.add('on');

  gpsWatch = navigator.geolocation.watchPosition(p => {
    const {latitude:lat, longitude:lng, accuracy:a} = p.coords;
    gpsAcc = a;
    $('acc').textContent = `±${Math.round(a)} m`;
    if(!gpsMarker){
      gpsMarker = L.circleMarker([lat,lng], {radius:5, color:'#0D100C', weight:2,
        fillColor:'#3FC8E4', fillOpacity:1}).addTo(map);
      gpsCircle = L.circle([lat,lng], {radius:a, color:'#3FC8E4', weight:1, opacity:.5,
        fillColor:'#3FC8E4', fillOpacity:.08}).addTo(map);
    }else{
      gpsMarker.setLatLng([lat,lng]);
      gpsCircle.setLatLng([lat,lng]).setRadius(a);
    }
    if(following){
      squelchUnfollow = true;
      centerOnReticle(L.latLng(lat, lng), Math.max(map.getZoom(), 19));
      setTimeout(() => { squelchUnfollow = false; }, 60);
    }
    syncGps();
  }, err => {
    following = false; gpsWatch = null;
    $('reticle').classList.remove('seeking');
    syncGps();
    toast(err.code === 1
      ? 'Location permission denied — pan the reticle instead'
      : 'No fix yet — pan the reticle to the plant');
  }, {enableHighAccuracy:true, maximumAge:2000, timeout:15000});
}

/* ---------------------------------------------------------- boundary
   Area is computed on the sphere, not the screen. You know your parcel is
   five acres, so the readout is a check on the whole coordinate pipeline. */
function ringArea(pts){
  if(pts.length < 3) return 0;
  const R = 6378137, d = Math.PI / 180;
  let a = 0;
  for(let i = 0; i < pts.length; i++){
    const p1 = pts[i], p2 = pts[(i + 1) % pts.length];
    a += (p2.lng - p1.lng) * d * (2 + Math.sin(p1.lat * d) + Math.sin(p2.lat * d));
  }
  return Math.abs(a * R * R / 2);
}
const acres = m2 => m2 / 4046.8564224;

function paintBoundary(geo){
  if(boundaryLayer) map.removeLayer(boundaryLayer);
  boundaryLayer = null;
  if(!geo) return;
  boundaryLayer = L.geoJSON(geo, {
    style:{color:'#E8E6DE', weight:2, opacity:.85, fill:false, dashArray:'6 5'}
  }).addTo(map);
}
function startDraw(){
  drawing = true; drawPts = []; drawDots = [];
  if(drawLine) map.removeLayer(drawLine);
  drawLine = null;
  map.closePopup();
  toggleSheet(false);
  $('drawBar').hidden = false;
  $('reticle').classList.add('drawing');
  $('mark').textContent = '⊕ Drop corner';
  $('drawArea').textContent = '';
  toast('Aim the reticle at each corner, then Drop corner');
}
function addCorner(){
  const p = reticleLatLng();
  drawPts.push(p);
  const dot = L.circleMarker(p, {radius:4, color:'#A578FF', weight:2,
    fillColor:'#0D100C', fillOpacity:1}).addTo(map);
  drawDots.push(dot);
  if(drawLine) map.removeLayer(drawLine);
  drawLine = L.polyline(drawPts.concat(drawPts.length > 2 ? [drawPts[0]] : []), {
    color:'#A578FF', weight:2, dashArray:'6 5'
  }).addTo(map);
  const a = acres(ringArea(drawPts));
  $('drawArea').textContent = drawPts.length > 2 ? `${a.toFixed(2)} ac` : `${drawPts.length} pt`;
}
function endDraw(save){
  drawing = false;
  $('drawBar').hidden = true;
  $('reticle').classList.remove('drawing');
  $('mark').textContent = '⊕ Mark here';
  drawDots.forEach(d => map.removeLayer(d));
  if(drawLine) map.removeLayer(drawLine);
  drawDots = []; drawLine = null;

  if(!save || drawPts.length < 3){ drawPts = []; return; }
  const geo = {
    type:'Polygon',
    coordinates:[[...drawPts.map(p => [p.lng, p.lat]), [drawPts[0].lng, drawPts[0].lat]]]
  };
  const a = acres(ringArea(drawPts));
  api('/api/config/boundary', {
    method:'PUT', headers:{'Content-Type':'application/json'}, body:JSON.stringify(geo)
  }).then(() => {
    cfg.boundary = geo;
    paintBoundary(geo);
    toast(`Boundary saved — ${a.toFixed(2)} acres`);
  }).catch(() => toast('Could not save the boundary'));
  drawPts = [];
}

/* ---------------------------------------------------------- offline */
async function prefetch(){
  const b = map.getBounds();
  const z = Math.round(map.getZoom());
  const btn = $('prefetchBtn');
  btn.disabled = true; btn.textContent = 'Downloading…';
  try{
    const r = await api('/api/prefetch', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body:JSON.stringify({
        src: cfg.basemap,
        north:b.getNorth(), south:b.getSouth(), east:b.getEast(), west:b.getWest(),
        zmin: Math.max(15, z), zmax: 20
      })
    });
    toast(r.requested === 0
      ? `Already cached to z${r.zmax_used}`
      : `Cached ${r.cached}/${r.requested} tiles to z${r.zmax_used}` +
        (r.zmax_used < 20 ? ` — ${cfg.basemap} publishes no deeper` : ''));
    await reload();
  }catch(e){
    toast(e.message);
  }finally{
    btn.disabled = false;
    btn.textContent = 'Cache this view for offline use';
  }
}

/* ---------------------------------------------------------- chrome */
function show(id){ $('scrim').classList.add('on'); $(id).classList.add('on'); }
function hide(id){ $(id).classList.remove('on'); $('scrim').classList.remove('on'); }
function toast(msg){
  const t = $('toast');
  t.textContent = msg; t.classList.add('on');
  clearTimeout(t._t);
  t._t = setTimeout(() => t.classList.remove('on'), 2600);
}
function toggleSheet(force){
  const s = $('sheet');
  const open = force != null ? force : !s.classList.contains('open');
  s.classList.toggle('open', open);
  $('grip').setAttribute('aria-expanded', String(open));
}

/* ---------------------------------------------------------- wiring */
function fillSelect(id, obj, useLabel){
  $(id).innerHTML = Object.entries(obj)
    .map(([k,v]) => `<option value="${k}">${useLabel ? v.label : v}</option>`).join('');
}
fillSelect('fForm', FORMS, true);
fillSelect('fStatus', STATUS, true);
fillSelect('fAbund', ABUND, false);
fillSelect('fPheno', PHENO, false);

$('chips').innerHTML = Object.entries(STATUS).map(([k,v]) =>
  `<button class="chip on" data-k="${k}"><span class="sw" style="background:${v.color}"></span>${v.label}</button>`
).join('');
$('chips').addEventListener('click', e => {
  const c = e.target.closest('.chip'); if(!c) return;
  const k = c.dataset.k;
  filters[k] = !filters[k];
  c.classList.toggle('on', filters[k]);
  c.classList.toggle('off', !filters[k]);
  drawMarkers(); drawList();
});

$('mark').addEventListener('click', () => {
  if(drawing){ addCorner(); return; }
  toggleSheet(false);
  openForm(null);
});
$('gps').addEventListener('click', toggleGps);
$('saveBtn').addEventListener('click', saveRec);
$('search').addEventListener('input', () => { drawMarkers(); drawList(); });

document.querySelectorAll('[data-close]').forEach(b =>
  b.addEventListener('click', () => hide(b.dataset.close)));
$('scrim').addEventListener('click', () => ['form','layers','data'].forEach(hide));
document.addEventListener('keydown', e => {
  if(e.key === 'Escape'){
    if(drawing){ endDraw(false); return; }
    ['form','layers','data'].forEach(hide);
  }
});

$('grip').addEventListener('click', () => toggleSheet());
$('grip').addEventListener('keydown', e => {
  if(e.key === 'Enter' || e.key === ' '){ e.preventDefault(); toggleSheet(); }
});
document.querySelectorAll('.tab').forEach(t => t.addEventListener('click', () => {
  document.querySelectorAll('.tab').forEach(x => x.classList.toggle('on', x === t));
  $('paneRecords').hidden = t.dataset.tab !== 'records';
  $('paneTaxa').hidden    = t.dataset.tab !== 'taxa';
  toggleSheet(true);
}));

$('list').addEventListener('click', e => {
  const dup = e.target.closest('[data-dup]');
  if(dup){ e.stopPropagation(); cloneRec(dup.dataset.dup); return; }
  const row = e.target.closest('.row'); if(!row) return;
  const r = records.find(x => x.id === row.dataset.id); if(!r) return;
  toggleSheet(false);
  map.setView([r.lat, r.lng], Math.max(map.getZoom(), 20));
  const m = markers.get(r.id);
  if(m) setTimeout(() => m.openPopup(), 340);
});

document.querySelectorAll('#fConf button').forEach(b => b.addEventListener('click', () => {
  draftConf = b.dataset.v;
  document.querySelectorAll('#fConf button').forEach(x => x.classList.toggle('on', x === b));
}));

/* picking a name you've used before back-fills what you already determined */
$('fSci').addEventListener('change', () => {
  const prev = records.find(r => r.scientific_name.toLowerCase() === $('fSci').value.trim().toLowerCase());
  if(!prev) return;
  if(!$('fCommon').value) $('fCommon').value = prev.common_name;
  if(!$('fFamily').value) $('fFamily').value = prev.family;
  $('fForm').value = prev.growth_form;
});

$('editCoord').addEventListener('click', () => {
  const box = $('coordEdit');
  box.hidden = !box.hidden;
  if(box.hidden){
    $('fLatTxt').textContent = fmt(parseFloat($('fLat').value) || 0);
    $('fLngTxt').textContent = fmt(parseFloat($('fLng').value) || 0);
  }
});
['fLat','fLng'].forEach(id => $(id).addEventListener('input', () => {
  draftSrc = 'manual'; draftAcc = null;
}));

$('photoInput').addEventListener('change', async e => {
  const files = [...e.target.files];
  e.target.value = '';
  if(!files.length) return;
  if(editingId){
    for(const f of files){
      try{
        const p = await uploadPhoto(editingId, f);
        formPhotos.push(p);
      }catch(err){ toast('Upload failed'); }
    }
    paintPhotoStrip();
    reload();
  }else{
    pendingPhotos.push(...files);
    paintPhotoStrip();
  }
});
$('photoStrip').addEventListener('click', async e => {
  const rm = e.target.closest('[data-rmphoto]');
  if(rm){
    await api(`/api/photos/${rm.dataset.rmphoto}`, {method:'DELETE'}).catch(()=>{});
    formPhotos = formPhotos.filter(p => p.id !== rm.dataset.rmphoto);
    paintPhotoStrip(); reload(); return;
  }
  const q = e.target.closest('[data-rmqueued]');
  if(q){
    pendingPhotos.splice(+q.dataset.rmqueued, 1);
    paintPhotoStrip();
  }
});

$('layersBtn').addEventListener('click', () => show('layers'));
document.querySelectorAll('#bmSeg button').forEach(b =>
  b.addEventListener('click', () => setBasemap(b.dataset.v)));
$('prefetchBtn').addEventListener('click', prefetch);

$('homeBtn').addEventListener('click', () => {
  const h = cfg.home;
  const atHome = Math.abs(map.getCenter().lat - h.lat) < 1e-5
              && Math.abs(map.getCenter().lng - h.lng) < 1e-5
              && Math.abs(map.getZoom() - h.zoom) < .5;
  if(atHome){
    const c = map.getCenter();
    cfg.home = {lat:c.lat, lng:c.lng, zoom:map.getZoom()};
    api('/api/config/home', {method:'PUT', headers:{'Content-Type':'application/json'},
      body:JSON.stringify(cfg.home)}).then(() => toast('Home view set to this frame'));
  }else{
    map.setView([h.lat, h.lng], h.zoom);
    toast('Home. Press ⌂ again here to save this frame as home.');
  }
});

$('exportBtn').addEventListener('click', () => {
  $('dataTitle').textContent = 'Export';
  $('exportPane').hidden = false;
  $('importPane').hidden = true;
  $('importGo').hidden = true;
  show('data');
});
$('importBtn').addEventListener('click', () => {
  $('dataTitle').textContent = 'Import';
  $('exportPane').hidden = true;
  $('importPane').hidden = false;
  $('importGo').hidden = false;
  $('importText').value = '';
  show('data');
});
$('importGo').addEventListener('click', async () => {
  let body;
  try{ body = JSON.parse($('importText').value); }
  catch(e){ toast('That is not valid JSON'); return; }
  try{
    const r = await api('/api/import', {
      method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body)
    });
    hide('data'); await reload();
    toast(`Merged ${r.imported} record${r.imported === 1 ? '' : 's'}` +
      (r.skipped ? ` · ${r.skipped} skipped (invalid fields)` : ''));
  }catch(e){ toast(e.message); }
});

$('boundaryBtn').addEventListener('click', () => {
  if(cfg.boundary && !confirm('Redraw the property boundary? The current one is replaced.')) return;
  startDraw();
});
$('drawUndo').addEventListener('click', () => {
  if(!drawPts.length) return;
  drawPts.pop();
  const d = drawDots.pop();
  if(d) map.removeLayer(d);
  if(drawLine) map.removeLayer(drawLine);
  drawLine = drawPts.length
    ? L.polyline(drawPts.concat(drawPts.length > 2 ? [drawPts[0]] : []),
        {color:'#A578FF', weight:2, dashArray:'6 5'}).addTo(map)
    : null;
  const a = acres(ringArea(drawPts));
  $('drawArea').textContent = drawPts.length > 2 ? `${a.toFixed(2)} ac` : `${drawPts.length} pt`;
});
$('drawDone').addEventListener('click', () => {
  if(drawPts.length < 3){ toast('A polygon needs at least three corners'); return; }
  endDraw(true);
});
$('drawCancel').addEventListener('click', () => endDraw(false));

$('fitBtn').addEventListener('click', () => {
  const rs = visible();
  if(!rs.length){ toast('Nothing to fit yet'); return; }
  map.fitBounds(L.latLngBounds(rs.map(r => [r.lat, r.lng])).pad(.25), {maxZoom:20});
  toggleSheet(false);
});

/* ---------------------------------------------------------- boot */
(async function(){
  cfg = await api('/api/config');
  setBasemap(cfg.basemap);
  map.setView([cfg.home.lat, cfg.home.lng], cfg.home.zoom);
  paintBoundary(cfg.boundary);
  paintCoords();
  await reload();
  if(!window.isSecureContext){
    toast('Served without TLS — GPS is off. Restart without --http.');
  }
})();
